import React from 'react';
import './AboutUs.css'; // Ajustar ruta si tu CSS está en otro lugar

export default function AboutUs() {
    return (
        <main className="about-container">
            <header className="about-hero">
                <h1>Sobre Nosotros</h1>
                <p className="subtitle">Transformando la experiencia de las compras en línea</p>
            </header>

            <section className="history-section">
                <div className="history-text">
                    <h2>Historia de la Compañía</h2>
                    <p>
                        GADU Container surge con el propósito de transformar la experiencia de las compras
                        en línea. Nuestra misión es ofrecer un servicio ágil, confiable y accesible,
                        eliminando la publicidad invasiva, los avisos molestos y las demoras en las entregas.
                        Facilitamos el proceso de pago y brindamos la posibilidad de adquirir productos desde
                        cualquier lugar y en cualquier momento, ya sea a través de un dispositivo móvil o un computador.
                        Todo esto con el compromiso de ofrecer artículos a precios justos y competitivos, inspirados
                        en los principios del Gran Arquitecto del Universo, quien guía nuestra visión de crear
                        soluciones para cada persona.
                    </p>
                </div>

                <div className="history-media" aria-hidden="false">
                    {/* Espacio para video o banner */}
                    {/* Reemplazar por: <video src="ruta.mp4" controls /> o un <img />/banner */}
                    <div className="media-placeholder">Espacio para video o banner</div>
                </div>
            </section>

            <section className="values-section">
                <h2>Nuestros Valores</h2>
                <ul className="values-list">
                    <li><strong>G</strong> – Gestión: eficiencia y organización en cada proceso.</li>
                    <li><strong>A</strong> – Atención: cercanía y excelencia en el servicio al cliente.</li>
                    <li><strong>D</strong> – Desarrollo: innovación constante en tecnología y comercio electrónico.</li>
                    <li><strong>U</strong> – Utilidad: soluciones prácticas y accesibles que generan valor real para nuestros usuarios.</li>
                </ul>
            </section>

            <section className="team-section">
                <h2>Equipo Directivo</h2>
                <div className="team-bubbles">
                    <div className="bubble">
                        <div className="avatar">
                            <img 
                                src="https://www.shutterstock.com/  image-photo/  portrait-handsome-ceo-man-260nw-123456789.    jpg" 
                                alt="Foto de Gerson Mercado" 
                            />
                        </div>
                        <div className="bubble-info">
                            <h3>Gerson Mercado</h3>
                            <p>CEO, CIO y Fundador. Visionario y creador del modelo de ecommerce de GADU Container, responsable de la estrategia tecnológica y del desarrollo de nuevas líneas de negocio.</p>
                        </div>
                    </div>

                    <div className="bubble">
                        <div className="avatar">
                        <img 
                                src="https://www.google.com/url?sa=i&url=https%3A%2F%2Fbrighterbox.com%2Fblog%2Farticle%2Ftop-4-traits-successful-startup-ceo&psig=AOvVaw2T-Rg76iGX5JgYRZcQzDMb&ust=1763846071974000&source=images&cd=vfe&opi=89978449&ved=2ahUKEwikqd7llISRAxXdeDABHQ7ROw8QjRx6BAgAEBo" 
                                alt="Foto de Nataly Gallego" 
                            />
                        </div>
                        <div className="bubble-info">
                            <h3>Nataly Gallego</h3>
                            <p>CEO, COO y Gerente de Comercio Internacional e Importaciones. Experta en gestión de operaciones globales, lidera la expansión internacional y fortalece las relaciones comerciales estratégicas.</p>
                        </div>
                    </div>
                </div>
            </section>
        </main>
    );
}