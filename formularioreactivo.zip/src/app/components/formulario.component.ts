// Importaciones necesarias de Angular
import { Component, ChangeDetectionStrategy, signal, computed } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators, ValidatorFn, AbstractControl } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';

@Component({
  // Este es el selector que se usa en index.html (<app-formulario></app-formulario>)
  selector: 'app-formulario',

  // Angular v20+ usa standalone components por defecto, no necesitamos NgModule
  standalone: true,

  // Importamos módulos que este componente necesita
  imports: [CommonModule, ReactiveFormsModule, MatSlideToggleModule],
  

  // Plantilla inline del formulario
  template: `

    <!-- Logo o imagen en el formulario -->
    <div class="logo-container">
      <img src="https://interrapidisimo.com/wp-content/uploads/interrapidisimo-1.png" alt="Interrapidisimo" class="logo" />
    </div>

    <!-- Formulario reactivo con accesibilidad -->
    <form [formGroup]="form" (ngSubmit)="onSubmit()" aria-label="Formulario de registro">
      
      <!-- Generamos dinámicamente los 10 campos definidos en el array "campos" -->
      <div class="campo" *ngFor="let campo of campos; let i = index">
        <!-- Etiqueta accesible asociada al input -->
        <label [for]="campo.id">{{ campo.label }}</label>

        <!-- Caso especial: si el campo es booleano, usamos mat-slide-toggle -->
        <ng-container *ngIf="campo.name === 'precarga'; else defaultInput">
          <mat-slide-toggle
            [id]="campo.id"
            formControlName="{{ campo.name }}">
            {{ campo.label }}
          </mat-slide-toggle>
        </ng-container>

        <!-- Para los demás tipos de input -->
        <ng-template #defaultInput>
          <input
            [id]="campo.id"
            [type]="campo.type"
            [formControlName]="campo.name"
            [attr.aria-invalid]="form.get(campo.name)?.invalid"
            [attr.aria-required]="true"
          />
        </ng-template>

        <!-- Mensaje de error accesible -->
        @if (form.get(campo.name)?.invalid && form.get(campo.name)?.touched) {
          <span class="error" role="alert">Campo inválido</span>
        }

        <!-- Error de coincidencia solo junto al campo de confirmación -->
        @if (
            campo.name === 'confirmPassword' &&
            form.hasError('passwordMismatch') &&
            form.get('confirmPassword')?.touched
          ) {
            <span class="error" role="alert">Las contraseñas no coinciden</span>
          }

      </div>

      <!-- Botón de envío deshabilitado si el formulario es inválido o está enviando -->
      <button type="submit" [disabled]="form.invalid || enviando()">Enviar</button>
    </form>

    <!-- Pop-up flotante -->
    <div class="popup" *ngIf="mostrarPopup">
      Información enviada satisfactoriamente ✅
    </div>

    <!-- Modal de iinformacion registrada -->
    <div class="modal" *ngIf="mostrarModal" aria-modal="true" role="dialog">
      <div class="modal-content" role="document">
        <h2>Información enviada</h2>
        <p>¡Tu información se registró en el TXT satisfactoriamente!</p>
        <button type="button" (click)="cerrarModal()">Cerrar</button>
      </div>
    </div>

  `,

  // Estrategia de detección de cambios optimizada
  changeDetection: ChangeDetectionStrategy.OnPush,

  // Importancion de hoja de estilos
  styleUrls: ['./formulario.component.css'],


  // Definimos estilos/atributos de host directamente en el decorador
  host: {
    class: 'formulario-container'
  }
})
export class FormularioComponent {

  //Codigo para mostrar el pop up
  mostrarPopup = false;

  //Codigo para mostrar el modal
  mostrarModal = false;

  // Instancia de FormBuilder para crear el formulario
  private fb = new FormBuilder();

  // Señal para controlar si se activa la precarga
  precargar = signal(false);

  // Definición de los 10 campos del formulario
  campos = [
    { id: 'precarga', name: 'precarga', label: 'Seleccione para verificar si existen datos', type: 'boolean' },
    { id: 'id', name: 'id', label: 'id', type: 'number' },
    { id: 'nombre', name: 'nombre', label: 'Nombre', type: 'text' },
    { id: 'apellido', name: 'apellido', label: 'Apellido', type: 'text' },
    { id: 'email', name: 'email', label: 'Correo electrónico', type: 'email' },
    { id: 'telefono', name: 'telefono', label: 'Teléfono', type: 'tel' },
    { id: 'direccion', name: 'direccion', label: 'Dirección', type: 'text' },
    { id: 'ciudad', name: 'ciudad', label: 'Ciudad', type: 'text' },
    { id: 'pais', name: 'pais', label: 'País', type: 'text' },
    { id: 'codigoPostal', name: 'codigoPostal', label: 'Código Postal', type: 'text' },
    { id: 'password', name: 'password', label: 'Contraseña', type: 'password' },
    { id: 'confirmPassword', name: 'confirmPassword', label: 'Confirmar Contraseña', type: 'password' }
  ];

  // Confirmacion del valor ingresado en contraseña
  private passwordMatchValidator: ValidatorFn = (group: AbstractControl) => {
    const password = group.get('password')?.value as string | undefined;
    const confirmPassword = group.get('confirmPassword')?.value as string | undefined;

    // Si hay valores en ambos y no coinciden marcarmos error en el grupo
    if (password !== confirmPassword) {
      return { passwordMismatch: true };
    }
    return null;
  }

  // Definición del formulario reactivo con validaciones
  form = this.fb.group({
    precarga: [false, Validators.requiredTrue],
    id: ['', [Validators.required, Validators.maxLength(10)]],
    nombre: ['', [Validators.required, Validators.minLength(2)]],
    apellido: ['', [Validators.required]],
    email: ['', [Validators.required, Validators.email]],
    telefono: ['', [Validators.required]],
    direccion: ['', [Validators.required]],
    ciudad: ['', [Validators.required]],
    pais: ['', [Validators.required]],
    codigoPostal: [{ value: 0, disabled: true }, [Validators.required]],
    password: ['', [Validators.required, Validators.minLength(6)]],
    confirmPassword: ['', [Validators.required]]    
  },
  {
    // Aplicamos el validador de coincidencia de contraseñas al grupo completo
    validators: this.passwordMatchValidator
  }
);

  // Señal para controlar si el formulario está en proceso de envío
  enviando = signal(false);

  // Estado derivado: el formulario es válido o no
  valido = computed(() => this.form.valid);

  // Método que se ejecuta al enviar el formulario
  onSubmit() {
    if (this.form.valid) {
      // Activamos estado de envío
      this.enviando.set(true);
      
      // Descargaremos la informacion ingresada en un documento TXT
      const datos = this.form.getRawValue(); // incluye codigoPostal deshabilitado
      const contenido = JSON.stringify(datos, null, 2);

      const blob = new Blob([contenido], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);

      const a = document.createElement('a');
      a.href = url;
      a.download = 'formulario.txt';
      a.click();
      
      URL.revokeObjectURL(url);

      // Mostramos los datos en consola (simulación de envío)
      console.log('Datos enviados:', this.form.value);

      // Logica del pop up con autocierre a los 3 segundos
      this.mostrarPopup = true;
      setTimeout(() => this.mostrarPopup = false, 3000); // se oculta en 3 segundos


      // Alerta en navegador
      alert('Información enviada satisfactoriamente');

      // Mostrar modal
      this.mostrarModal = true;

      // Simulamos un retraso de 2 segundos y luego desactivamos "enviando"
      setTimeout(() => this.enviando.set(false), 2000);
    } else {
      // Si el formulario es inválido, marcamos todos los campos como tocados
      this.form.markAllAsTouched();
    }
  }

  // Cerrar modal
  cerrarModal() {
    this.mostrarModal = false;
  }

}
