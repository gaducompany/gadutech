import { bootstrapApplication } from '@angular/platform-browser';
import { FormularioComponent } from './app/components/formulario.component';

bootstrapApplication(FormularioComponent)
  .catch(err => console.error(err));
