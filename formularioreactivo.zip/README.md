🛠️ Tecnologías utilizadas
Angular (v20+) → Framework principal para construir la aplicación.

TypeScript → Lenguaje de programación tipado que compila a JavaScript.

Angular Material → Librería de componentes UI (en este caso MatSlideToggleModule).

Reactive Forms → API de Angular para formularios reactivos con validaciones.

Signals y computed → Nueva API de Angular para manejar estado reactivo sin necesidad de RxJS.

HTML + CSS → Para la plantilla y estilos del formulario.

📦 Módulos que se importan y para qué sirven
CommonModule

Proporciona directivas básicas de Angular (ngIf, ngFor).

ReactiveFormsModule

Permite crear formularios reactivos, manejar validaciones y estados.

MatSlideToggleModule

Componente de Angular Material para switches/checkbox booleanos.

FormBuilder, Validators, ValidatorFn

Herramientas para construir el formulario y aplicar reglas de validación.

ChangeDetectionStrategy.OnPush

Optimiza la detección de cambios para mejorar rendimiento.

📑 Tipo de formulario
Este es un Formulario Reactivo (Reactive Form) en Angular. Características:

Se define en el TypeScript con FormBuilder.

Usa validaciones síncronas (Validators.required, Validators.email, etc.).

Tiene un validador personalizado para confirmar contraseñas (passwordMatchValidator).

Los campos se generan dinámicamente desde un array (campos).

Incluye un toggle booleano (mat-slide-toggle) para la opción de precarga.

Al enviar, descarga la información en un archivo .txt y muestra popup + modal de confirmación + Alert en navegador.

🚚 En contexto de una transportadora
Este tipo de formulario podría usarse para:

Registro de clientes o usuarios.

Captura de datos de envío (nombre, dirección, ciudad, país, código postal).

Validación de credenciales (contraseña y confirmación).

Activación de opciones especiales (ej. precarga de datos).