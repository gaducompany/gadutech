// src/pages/Users.jsx
import React, { useState } from "react";
import "./Users.css";

const Users = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({
    displayName: "",
    email: "",
    password: "",
    phoneNumber: ""
  });

  const [errors, setErrors] = useState({
    email: "",
    phoneNumber: ""
  });

  const validateEmail = (email) => {
    if (!email) return "El correo es obligatorio.";
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email) ? "" : "Ingrese un correo válido.";
  };

  const validatePhone = (phone) => {
    if (!phone) return "El teléfono es obligatorio.";
    const digits = phone.replace(/\D/g, "");
    if (digits.length < 7 || digits.length > 15) return "Ingrese un teléfono válido (7–15 dígitos).";
    return "";
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });

    // Validar en cada cambio para feedback inmediato
    if (name === "email") {
      setErrors((prev) => ({ ...prev, email: validateEmail(value) }));
    }
    if (name === "phoneNumber") {
      setErrors((prev) => ({ ...prev, phoneNumber: validatePhone(value) }));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Validación final antes de submit
    const emailError = validateEmail(formData.email);
    const phoneError = isLogin ? "" : validatePhone(formData.phoneNumber);

    setErrors({ email: emailError, phoneNumber: phoneError });

    if (emailError || phoneError) {
      return; // evitar submit si hay errores
    }

    try {
      if (isLogin) {
        // Simular login localmente por ahora
        alert(`Bienvenido de nuevo ${formData.displayName || formData.email || "usuario"}`);
      } else {
        // Simular registro localmente por ahora
        alert(`Cuenta (simulada) creada para ${formData.displayName || formData.email}`);
        // opcional: limpiar formulario
        setFormData({
          displayName: "",
          email: "",
          password: "",
          phoneNumber: ""
        });
        setIsLogin(true);
      }
    } catch (error) {
      console.error(error);
      alert("Ocurrió un error.");
    }
  };

  return (
    <div className="users-container">
      <div className="users-card">
        <img
          src="https://firebasestorage.googleapis.com/v0/b/appgaduecommerce.firebasestorage.app/o/Gadu%2FLogoGADU.png?"
          alt="GADU Logo"
          className="users-logo"
          loading="lazy"
        />
        <h2>{isLogin ? "Iniciar Sesión" : "Registrarse"}</h2>
        <form onSubmit={handleSubmit} noValidate>
          {!isLogin && (
            <input
              type="text"
              name="displayName"
              placeholder="Nombre completo"
              value={formData.displayName}
              onChange={handleChange}
            />
          )}
          <input
            type="email"
            name="email"
            placeholder="Correo electrónico"
            value={formData.email}
            onChange={handleChange}
            required
          />
          {errors.email && <small className="error-text">{errors.email}</small>}
          <input
            type="password"
            name="password"
            placeholder="Contraseña"
            value={formData.password}
            onChange={handleChange}
            required
          />
          {!isLogin && (
            <>
              <input
                type="tel"
                name="phoneNumber"
                placeholder="Teléfono"
                value={formData.phoneNumber}
                onChange={handleChange}
              />
              {errors.phoneNumber && <small className="error-text">{errors.phoneNumber}</small>}
            </>
          )}
          <button type="submit" className="btn-primary">
            {isLogin ? "Entrar" : "Crear cuenta"}
          </button>
        </form>
        <p className="toggle-text">
          {isLogin ? "¿No tienes cuenta?" : "¿Ya tienes cuenta?"}
          <span onClick={() => setIsLogin(!isLogin)}>
            {isLogin ? " Regístrate" : " Inicia sesión"}
          </span>
        </p>
      </div>
    </div>
  );
};

export default Users;
