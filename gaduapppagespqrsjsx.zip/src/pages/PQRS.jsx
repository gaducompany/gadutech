import React, { useState, useEffect } from "react";
import "./PQRS.css";

export default function PQRS() {
    const STORAGE_KEY = "pqrs_list_v1";

    const [usuario, setUsuario] = useState("");
    const [asunto, setAsunto] = useState("");
    const [descripcion, setDescripcion] = useState("");
    const [celular, setCelular] = useState("");
    const [pqrsList, setPqrsList] = useState([]);
    const [selected, setSelected] = useState(null);
    const [showModal, setShowModal] = useState(false);
    const [searchTerm, setSearchTerm] = useState("");

    useEffect(() => {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (raw) setPqrsList(JSON.parse(raw));
    }, []);

    useEffect(() => {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(pqrsList));
    }, [pqrsList]);

    function formatDate(iso) {
        const d = new Date(iso);
        return d.toLocaleString();
    }

    function resetForm() {
        setUsuario("");
        setAsunto("");
        setDescripcion("");
        setCelular("");
    }

    function handleSubmit(e) {
        e.preventDefault();
        if (!usuario || !asunto || !descripcion || !celular) {
            alert("Complete todos los campos.");
            return;
        }
        const newPQRS = {
            id: String(Date.now()), // simple id
            usuario,
            asunto,
            descripcion,
            celular,
            fechaRegistro: new Date().toISOString(),
            estado: "Iniciado",
        };
        setPqrsList([newPQRS, ...pqrsList]);
        resetForm();
        alert("PQRS registrada correctamente. Estado: Iniciado");
    }

    function openPQRS(p) {
        setSelected(p);
        setShowModal(true);
    }

    function handleSearch() {
        if (!searchTerm.trim()) {
            alert("Ingrese ID o celular para consultar.");
            return;
        }
        const found = pqrsList.find(
            (p) => p.id === searchTerm.trim() || p.celular === searchTerm.trim()
        );
        if (!found) {
            alert("No se encontró PQRS con ese ID / celular.");
            return;
        }
        openPQRS(found);
    }

    function estadoBadgeClass(estado) {
        if (!estado) return "badge";
        const key = estado.toLowerCase();
        if (key.includes("iniciado")) return "badge badge-iniciado";
        if (key.includes("proceso") || key.includes("proceso")) return "badge badge-proceso";
        if (key.includes("cerrado")) return "badge badge-cerrado";
        return "badge";
    }

    return (
        <div className="pqrs-page">
            <div className="pqrs-card">
                <h2>Crear PQRS</h2>

                <form onSubmit={handleSubmit} className="pqrs-form">
                    <div className="pqrs-row">
                        <label className="pqrs-label">Usuario</label>
                        <input className="pqrs-input" value={usuario} onChange={(e) => setUsuario(e.target.value)} />
                    </div>

                    <div className="pqrs-row">
                        <label className="pqrs-label">Asunto</label>
                        <input className="pqrs-input" value={asunto} onChange={(e) => setAsunto(e.target.value)} />
                    </div>

                    <div className="pqrs-row">
                        <label className="pqrs-label">Descripción</label>
                        <textarea className="pqrs-textarea" value={descripcion} onChange={(e) => setDescripcion(e.target.value)} rows={4} />
                    </div>

                    <div className="pqrs-row">
                        <label className="pqrs-label">Celular</label>
                        <input className="pqrs-input" value={celular} onChange={(e) => setCelular(e.target.value)} />
                    </div>

                    <div className="controls">
                        <button type="submit" className="btn btn-primary">Registrar PQRS</button>
                        <button type="button" className="btn btn-ghost" onClick={resetForm}>Limpiar</button>
                    </div>
                </form>

                <hr />

                <h3>Consultar estado</h3>
                <div className="search-row">
                    <input
                        className="pqrs-search"
                        placeholder="Ingrese ID o celular"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                    <button className="btn btn-primary" onClick={handleSearch}>Consultar</button>
                </div>

                <hr />

                <h3>Listado de PQRS</h3>
                {pqrsList.length === 0 ? (
                    <p className="empty">No hay PQRS registradas.</p>
                ) : (
                    <table className="pqrs-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Usuario</th>
                                <th>Asunto</th>
                                <th>Fecha</th>
                                <th>Estado</th>
                                <th>Acción</th>
                            </tr>
                        </thead>
                        <tbody>
                            {pqrsList.map((p) => (
                                <tr key={p.id}>
                                    <td className="pqrs-id">{p.id}</td>
                                    <td>{p.usuario}</td>
                                    <td>{p.asunto}</td>
                                    <td>{formatDate(p.fechaRegistro)}</td>
                                    <td>
                                        <span className={estadoBadgeClass(p.estado)}>{p.estado}</span>
                                    </td>
                                    <td>
                                        <button className="btn btn-ghost" onClick={() => openPQRS(p)}>Ver</button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                )}
            </div>

            {showModal && selected && (
                <div className="pqrs-modal" onClick={() => setShowModal(false)} role="dialog" aria-modal="true">
                    <div className="pqrs-modal-dialog" onClick={(e) => e.stopPropagation()}>
                        <h3>Detalle PQRS</h3>
                        <p><strong>ID:</strong> {selected.id}</p>
                        <p><strong>Usuario:</strong> {selected.usuario}</p>
                        <p><strong>Asunto:</strong> {selected.asunto}</p>
                        <p><strong>Descripción:</strong> {selected.descripcion}</p>
                        <p><strong>Celular:</strong> {selected.celular}</p>
                        <p><strong>Fecha de registro:</strong> {formatDate(selected.fechaRegistro)}</p>
                        <p><strong>Estado actual:</strong> <span className={estadoBadgeClass(selected.estado)}>{selected.estado}</span></p>

                        <div className="modal-actions">
                            <button className="btn btn-ghost" onClick={() => setShowModal(false)}>Cerrar</button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}